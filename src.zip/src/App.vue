<template>
  <div id="q-app">
    <router-view />
  </div>
</template>

<script>
import Cookies from 'js-cookie';
export default {
  name: 'App'
}
</script>
