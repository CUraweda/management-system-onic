// src/event-bus.js
import Vue from 'vue';
export const eventBus = new Vue();
