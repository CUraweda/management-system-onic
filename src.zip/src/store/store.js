import { reactive } from "vue";

export const store = reactive({
  id: 0,
});
